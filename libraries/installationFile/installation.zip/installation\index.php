<?php
    require 'define.php';
    
    include 'controller/default.php';