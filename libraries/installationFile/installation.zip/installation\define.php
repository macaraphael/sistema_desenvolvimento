<?php
/*Caminho do arquivo*/
define('SFULLPATH', __FILE__);
define('SDIRECTORY', dirname(__FILE__));